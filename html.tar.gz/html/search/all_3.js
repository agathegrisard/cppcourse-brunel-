var searchData=
[
  ['isrefractory',['isRefractory',['../classNeuron.html#a1c42205232c387e6e48fd7a34917a4a9',1,'Neuron']]],
  ['isspiking',['isSpiking',['../classNeuron.html#a80bb77af9e3d56e6986e0d78b8ba1010',1,'Neuron']]]
];
