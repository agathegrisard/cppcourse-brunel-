var searchData=
[
  ['setexcitatory',['setExcitatory',['../classNeuron.html#aee068e79e1a8c1ef0be8548dc6728b18',1,'Neuron']]],
  ['setextcurrent',['setExtCurrent',['../classNeuron.html#ad3505ba8e55d64e7144e1d83337c2ed4',1,'Neuron']]],
  ['setid',['setId',['../classNeuron.html#a222df129e8f40309034052b85447d603',1,'Neuron']]],
  ['setmembpot',['setMembPot',['../classNeuron.html#a05ef2a79941a8d93e1a4a60defd4e121',1,'Neuron']]]
];
